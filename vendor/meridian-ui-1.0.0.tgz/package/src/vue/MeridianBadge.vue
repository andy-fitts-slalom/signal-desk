<script setup lang="ts">
withDefaults(defineProps<{ tone?: 'neutral'|'success'|'warning'|'danger'|'info' }>(),{tone:'neutral'});
</script>
<template><span :class="['ms-badge',`ms-tone-${tone}`]"><slot /></span></template>
