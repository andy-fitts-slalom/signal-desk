<script setup lang="ts">
defineProps<{ title:string; description:string }>();
</script>
<template><section class="ms-empty"><h2>{{ title }}</h2><p class="ms-muted">{{ description }}</p><div class="ms-cluster" style="justify-content:center"><slot /></div></section></template>
