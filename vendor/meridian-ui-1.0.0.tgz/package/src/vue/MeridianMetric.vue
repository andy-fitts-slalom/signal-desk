<script setup lang="ts">
defineProps<{ label: string; value: string|number; note: string }>();
</script>
<template><div class="ms-surface"><dl class="ms-metric"><dt>{{ label }}</dt><dd>{{ value }}</dd></dl><p class="ms-metric__note">{{ note }}</p></div></template>
