<script setup lang="ts">
withDefaults(defineProps<{ title: string; tone?: 'neutral'|'success'|'warning'|'danger'|'info'; announcement?: 'off'|'polite'|'assertive' }>(),{tone:'info',announcement:'off'});
</script>
<template><div :class="['ms-notice',`ms-tone-${tone}`]" :role="announcement === 'assertive' ? 'alert' : announcement === 'polite' ? 'status' : undefined"><strong class="ms-notice__title">{{ title }}</strong><slot /><div v-if="$slots.actions" class="ms-notice__actions"><slot name="actions" /></div></div></template>
