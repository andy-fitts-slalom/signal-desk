<script setup lang="ts">
import mark from '../../assets/brand/meridian-mark.svg';
defineProps<{ product?: string; href?: string }>();
</script>
<template>
 <component :is="href ? 'a' : 'div'" :href="href" class="ms-brand">
  <img :src="mark" alt="" width="40" height="40" class="ms-brand__mark" />
  <span><span class="ms-brand__name">MERIDIAN</span><span class="ms-brand__descriptor">SIGNAL GROUP</span><span v-if="product" class="ms-brand__product">{{ product }}</span></span>
 </component>
</template>
